
#' D3 Layout widget (uses {nodes, edges}) with fixed grid spacing = 5
#' @param nodes data.frame with column `name`
#' @param edges data.frame with columns `from`,`to`
#' @export
layoutWidget <- function(nodes, edges, width = NULL, height = NULL, elementId = NULL) {
  stopifnot(is.data.frame(nodes), is.data.frame(edges))
  if (!"name" %in% names(nodes)) stop("`nodes` must have a `name` column")
  if (!all(c("from","to") %in% names(edges))) stop("`edges` must have `from` and `to` columns")

  nodes$name <- as.character(nodes$name)
  edges$from <- as.character(edges$from)
  edges$to   <- as.character(edges$to)

  x <- list(
    nodes_json = jsonlite::toJSON(nodes, dataframe = "rows", auto_unbox = TRUE),
    edges_json = jsonlite::toJSON(edges, dataframe = "rows", auto_unbox = TRUE)
  )

  deps <- list(
    htmltools::htmlDependency(
      name = "d3",
      version = "7",
      src = c(href = "https://d3js.org"),
      script = "d3.v7.min.js"
    )
  )

  htmlwidgets::createWidget(
    name = "layoutWidget",
    x = x,
    width = width,
    height = height,
    package = "layoutWidget",
    elementId = elementId,
    dependencies = deps
  )
}

