
# ---------- Helpers ----------
.strip_comments <- function(model_lines) {
  model_lines <- gsub("#.*$", "", model_lines)
  trimws(model_lines)
}

.extract_model_block <- function(model_lines) {
  txt <- paste(model_lines, collapse = "\n")
  mstart <- regexpr("\\bmodel\\s*\\{", txt, perl = TRUE)
  if (mstart[1] == -1) stop("No 'model { ... }' block found.")
  start <- as.integer(mstart) + attr(mstart, "match.length")
  depth <- 1L; i <- start; end_pos <- NA_integer_
  while (i <= nchar(txt)) {
    ch <- substr(txt, i, i)
    if (ch == "{") depth <- depth + 1L
    if (ch == "}") { depth <- depth - 1L; if (depth == 0L) { end_pos <- i; break } }
    i <- i + 1L
  }
  if (is.na(end_pos)) stop("Could not find closing '}' for model block.")
  block <- substr(txt, start, end_pos - 1L)
  blines <- unlist(strsplit(block, "\n", fixed = TRUE))
  blines <- blines[nzchar(trimws(blines))]
  blines
}

.normalize_index <- function(name) gsub("\\[[^\\]]*\\]", "[]", name, perl = TRUE)

.tokenize_symbols <- function(expr) {
  m <- gregexpr("\\b[A-Za-z_][A-Za-z0-9_.]*\\b(?:\\[[^\\]]+\\])?", expr, perl = TRUE)
  if (length(m) == 0L || m[[1]][1] == -1) return(character(0))
  unique(regmatches(expr, m)[[1]])
}

.is_numeric_like <- function(tok) {
  grepl("^([0-9]+(\\.[0-9]*)?|\\.[0-9]+)([eE][+-]?[0-9]+)?$", tok)
}

.ignore_set <- c(
  "model","for","in","if","else","T","F","NA","TRUE","FALSE",
  "I","log","log10","exp","sqrt","pow","abs","step","ceil","floor","round","phi",
  "cos","sin","tan","acos","asin","atan","max","min","mean","sd","sum","prod","length",
  # distributions
  "dbern","dbin","dcat","ddirch","ddexp","dgamma","dlnorm","dlogis","dnorm",
  "dpar","dpois","dunif","dweib","dmulti","dmnorm","dmvnorm","dwish","dinvgamma",
  "dhyper","dnbinom","dt","dchisqr","dexp","dbeta",
  # link helpers
  "cloglog","logit","probit","ilogit","equals","inprod"
)

# Combine soft-wrapped lines using a last-character heuristic
.coalesce_lines <- function(model_lines) {
  out <- character(0); buf <- ""
  for (ln in model_lines) {
    s <- trimws(ln); if (!nzchar(s)) next
    buf <- paste0(buf, " ", s)
    last_char <- if (nzchar(s)) substr(s, nchar(s), nchar(s)) else ""
    if (last_char %in% c(",", "+", "-", "*", "/", "^", "=")) next
    out <- c(out, trimws(buf)); buf <- ""
  }
  if (nzchar(trimws(buf))) out <- c(out, trimws(buf))
  out
}

# ---------- Main ----------
#' Parse BUGS/JAGS code into nodes and edges
#' @param model_text Character string containing BUGS/JAGS code
#' @return A list with elements `nodes` (data.frame) and `edges` (data.frame)
#' @export
parse_dependencies <- function(model_text) {
  raw <- unlist(strsplit(model_text, "\n", fixed = TRUE))
  raw <- .strip_comments(raw)
  model_lines <- .extract_model_block(raw)
  model_lines <- .coalesce_lines(model_lines)

  from_vec <- character(); to_vec <- character()
  for (line in model_lines) {
    LHS <- RHS <- NULL
    if (grepl("~", line, fixed = TRUE)) {
      parts <- strsplit(line, "~", fixed = TRUE)[[1]]
      if (length(parts) >= 2) { LHS <- trimws(parts[1]); RHS <- paste(parts[-1], collapse = "~") }
    }
    if (is.null(LHS) && grepl("<-", line, fixed = TRUE)) {
      parts <- strsplit(line, "<-", fixed = TRUE)[[1]]
      if (length(parts) >= 2) { LHS <- trimws(parts[1]); RHS <- paste(parts[-1], collapse = "<-") }
    }
    if (is.null(LHS) || is.null(RHS)) next

    LHS <- sub("\\s+.*$", "", LHS)
    LHSn <- .normalize_index(LHS)

    toks <- .tokenize_symbols(RHS)
    parents <- toks[!toks %in% .ignore_set & !.is_numeric_like(toks)]
    parents <- parents[parents != LHS]
    parents <- unique(.normalize_index(parents))

    if (length(parents)) {
      from_vec <- c(from_vec, parents)
      to_vec   <- c(to_vec, rep(LHSn, length(parents)))
    }
  }

  edges <- unique(data.frame(from = from_vec, to = to_vec, stringsAsFactors = FALSE))
  nodes <- data.frame(name = sort(unique(c(edges$from, edges$to))), stringsAsFactors = FALSE)
  list(nodes = nodes, edges = edges)
}

#' Example JAGS model string
#' @return Character scalar
#' @export
example_jags_model <- function() {
  paste(c(
    "# Model",
    "model{",
    "  # Data analysis",
    "  for (tmt in 1:2){                                      # Treatments tmt=1 (Seretide), tmt=2 (Fluticasone)",
    "    for (i in 1:4){                                      # There are 4 non-absorbing health states",
    "      r[tmt,i,1:5] ~ dmulti(pi[tmt,i,1:5], n[tmt,i])    # Multinomial DATA",
    "      pi[tmt,i,1:5] ~ ddirch(prior[tmt,i,1:5])          # Dirichlet prior for probs.",
    "    }",
    "  }",
    "  # Calculating summaries from a decision model",
    "  for (tmt in 1:2){",
    "    for (i in 1:5){ s[tmt,i,1] <- equals(i,1) }         # Initialise starting state",
    "    for (i in 1:4){",
    "      for (t in 2:13){",
    "        s[tmt,i,t] <- inprod(s[tmt,1:4,t-1], pi[tmt,1:4,i])  # 12 cycles",
    "      }",
    "      E[tmt,i] <- sum(s[tmt,i,2:13])",
    "    }",
    "    E[tmt,5] <- 12 - sum(E[tmt,1:4])",
    "  }",
    "  for (i in 1:5){",
    "    D[i] <- E[1,i] - E[2,i]",
    "    prob[i] <- step(D[i])",
    "  }",
    "}"
  ), collapse = "\n")
}

#' Demo: parse example JAGS and open the layout widget
#' @export
demo_layoutWidget <- function(width = NULL, height = NULL) {
  pe <- parse_dependencies(example_jags_model())
  layoutWidget(pe$nodes, pe$edges, width = width, height = height)
}

