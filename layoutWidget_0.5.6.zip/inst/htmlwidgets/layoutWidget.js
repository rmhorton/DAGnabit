HTMLWidgets.widget({
  name: "layoutWidget",
  type: "output",
  factory: function(el, width, height) {
    el.innerHTML = "";
    const root = document.createElement("div");
    root.style.position = "relative";
    root.style.width = "100%";
    root.style.height = "100%";
    el.appendChild(root);

    const sidebar = document.createElement("div");
    sidebar.id = "sidebar";
    sidebar.style.position = "absolute";
    sidebar.style.left = "0"; sidebar.style.top = "0"; sidebar.style.bottom = "0";
    sidebar.style.width = "200px";
    sidebar.style.background = "#f4f4f4";
    sidebar.style.borderRight = "1px solid #ccc";
    sidebar.style.padding = "10px";
    sidebar.style.boxSizing = "border-box";
    sidebar.innerHTML = "<button id=\"fit\">Fit to view</button><br><br>" +
                        "<button id=\"saveSVG\">Export SVG</button><br>" +
                        "<button id=\"savePNG\">Export PNG</button>";
    root.appendChild(sidebar);

    const graph = document.createElement("div");
    graph.id = "graph";
    graph.style.position = "absolute";
    graph.style.left = "200px"; graph.style.top = "0"; graph.style.right = "0"; graph.style.bottom = "0";
    root.appendChild(graph);

    const svg = d3.select(graph).append("svg")
      .attr("width", graph.clientWidth)
      .attr("height", graph.clientHeight);

    svg.append("defs").append("marker")
      .attr("id", "arrow")
      .attr("viewBox", "0 -5 10 10")
      .attr("refX", 18)
      .attr("refY", 0)
      .attr("markerWidth", 6)
      .attr("markerHeight", 6)
      .attr("orient", "auto")
      .append("path")
      .attr("d", "M0,-5L10,0L0,5")
      .attr("fill", "#666");

    const g = svg.append("g");
    const gridSpacing = 5;

    function safeParse(v) {
      if (Array.isArray(v)) return v;
      if (typeof v === "object" && v !== null) return Object.values(v);
      if (typeof v === "string") {
        try { return JSON.parse(v); } catch(e) { return []; }
      }
      return [];
    }

    function build(x) {
      const nodes = safeParse(x.nodes_json);
      const edges = safeParse(x.edges_json).map(e => ({ source: e.from, target: e.to }));
      g.selectAll("*").remove();

      const link = g.selectAll(".link")
        .data(edges).enter().append("line")
        .attr("stroke", "#666").attr("stroke-width", 1.5)
        .attr("marker-end", "url(#arrow)");

      const node = g.selectAll(".node")
        .data(nodes, d => d.name).enter().append("g")
        .attr("class", "node")
        .call(d3.drag().on("drag", dragged));

      node.append("ellipse")
        .attr("rx", 45).attr("ry", 25)
        .attr("fill", "#6fa").attr("stroke", "#333").attr("stroke-width", 1.5);

      node.append("text")
        .attr("text-anchor", "middle").attr("dy", 4)
        .text(d => d.name);

      function dragged(event, d) {
        d.x = Math.round(event.x / gridSpacing) * gridSpacing;
        d.y = Math.round(event.y / gridSpacing) * gridSpacing;
        d3.select(this).attr("transform", `translate(${d.x},${d.y})`);
        updateLinks();
      }
      function updateLinks() {
        link.attr("x1", d => findNode(d.source).x)
            .attr("y1", d => findNode(d.source).y)
            .attr("x2", d => findNode(d.target).x)
            .attr("y2", d => findNode(d.target).y);
      }
      function findNode(name) { return nodes.find(n => n.name === name) || {x:0,y:0}; }

      // simple initial positions
      nodes.forEach((n,i)=>{ n.x=200+i*150; n.y=200+(i%2)*150; });
      node.attr("transform", d => `translate(${d.x},${d.y})`);
      updateLinks();

      // toolbar actions
      const fitBtn = root.querySelector("#fit");
      if (fitBtn) fitBtn.onclick = () => {
        const bounds = g.node().getBBox();
        const W = graph.clientWidth, H = graph.clientHeight;
        const dx = bounds.width || 1, dy = bounds.height || 1;
        const x = bounds.x + dx/2, y = bounds.y + dy/2;
        const scale = 0.9/Math.max(dx/W, dy/H);
        const translate = [W/2 - scale*x, H/2 - scale*y];
        g.transition().duration(750).attr("transform", `translate(${translate}) scale(${scale})`);
      };

      const saveSVG = root.querySelector("#saveSVG");
      if (saveSVG) saveSVG.onclick = () => {
        const serializer = new XMLSerializer();
        let source = serializer.serializeToString(svg.node());
        if(!source.match(/^<svg[^>]+xmlns=\"http:\/\/www\.w3\.org\/2000\/svg\"/)) {
          source = source.replace(/^<svg/, '<svg xmlns="http://www.w3.org/2000/svg"');
        }
        const url = "data:image/svg+xml;charset=utf-8," + encodeURIComponent(source);
        const a = document.createElement("a"); a.href = url; a.download = "layout.svg"; a.click();
      };

      const savePNG = root.querySelector("#savePNG");
      if (savePNG) savePNG.onclick = () => {
        const serializer = new XMLSerializer();
        const source = serializer.serializeToString(svg.node());
        const img = new Image();
        const canvas = document.createElement("canvas");
        const W = graph.clientWidth, H = graph.clientHeight;
        canvas.width = W; canvas.height = H;
        const ctx = canvas.getContext("2d");
        const svgBlob = new Blob([source], {type:"image/svg+xml;charset=utf-8"});
        const url = URL.createObjectURL(svgBlob);
        img.onload = function(){
          ctx.fillStyle = "#fff"; ctx.fillRect(0,0,W,H);
          ctx.drawImage(img,0,0);
          URL.revokeObjectURL(url);
          const png = canvas.toDataURL("image/png");
          const a = document.createElement("a"); a.href = png; a.download = "layout.png"; a.click();
        };
        img.src = url;
      };
    }

    return {
      renderValue: function(x){ build(x); },
      resize: function(w,h){
        d3.select(graph).select("svg").attr("width", graph.clientWidth).attr("height", graph.clientHeight);
      }
    };
  }
});
